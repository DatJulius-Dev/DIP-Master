@echo off
title DMS Cyber Dashboard - Streamlit + Ngrok Public Tunnel
chcp 65001 >nul
echo ==============================================================================
echo [INFO] Dang khoi chay DMS Cyber Dashboard ket hop Ngrok Public Tunnel...
echo ==============================================================================
python run_with_ngrok.py
pause
