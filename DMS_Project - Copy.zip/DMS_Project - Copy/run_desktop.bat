@echo off
title DMS Desktop HUD - TDTU DIP 2026
echo [INFO] Dang khoi chay Desktop HUD ADAS OpenCV...
python app_opencv.py
pause
