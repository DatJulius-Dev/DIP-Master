@echo off
title DMS Cyber Dashboard - TDTU DIP 2026
echo [INFO] Dang khoi chay Streamlit Web Application...
python -m streamlit run app_streamlit.py
pause
