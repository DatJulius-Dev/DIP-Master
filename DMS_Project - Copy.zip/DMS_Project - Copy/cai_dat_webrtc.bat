@echo off
chcp 65001 >nul
echo ========================================================================
echo   CAI DAT THU VIEN WEBRTC LIVE STREAMING CHO CAMERA TU XA
echo ========================================================================
echo.
echo [*] Dang cai dat streamlit-webrtc va av...
python -m pip install streamlit-webrtc av
echo.
echo [+] Cai dat hoan tat! Ban co the khoi dong lai ung dung de dung Video Live WebRTC.
echo ========================================================================
pause
