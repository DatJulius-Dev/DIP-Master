# FINGERPRINT BIOMETRIC MASTER RESEARCH DASHBOARD

Hệ thống Web Dashboard nghiên cứu và thực nghiệm Nhận diện Vân tay chuẩn mực bậc Thạc sĩ (Classical Computer Vision).

## Hướng dẫn cài đặt & chạy:
1. Cài đặt thư viện:
   pip install -r requirements.txt

2. Chạy Dashboard:
   python app_fingerprint_dashboard.py

Sau khi chạy, Gradio sẽ cấp phát tự động đường link trực tiếp (https://xxxx.gradio.live) để gửi thầy cô truy cập trực tiếp trên trình duyệt web!
